
  # Energy Management System Dashboard

  This is a code bundle for Energy Management System Dashboard. The original project is available at https://www.figma.com/design/47borKsFSxIVFsGHR2K6KT/Energy-Management-System-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  